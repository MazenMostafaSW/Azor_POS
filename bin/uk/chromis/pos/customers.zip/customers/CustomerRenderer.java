/*
**    Chromis POS  - Open Source Point of Sale
**
**    This file is part of Chromis POS Version Chromis V1.4.8
**    Copyright 2015-2022 
**
**    http://www.chromis.co.uk
**
**
 */


package uk.chromis.pos.customers;

import java.awt.Component;
import javax.swing.DefaultListCellRenderer;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JList;
import uk.chromis.globals.IconFactory;


public class CustomerRenderer extends DefaultListCellRenderer {
                
    private Icon icocustomer;

    public CustomerRenderer() {

      //  icocustomer = new ImageIcon(getClass().getClassLoader().getResource("customer_sml.png"));
        icocustomer =IconFactory.getIcon("customer_sml.png");
        
    }

    @Override
    public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        super.getListCellRendererComponent(list, null, index, isSelected, cellHasFocus);
        setText(value.toString());
        setIcon(icocustomer);
        return this;
    }      
}
